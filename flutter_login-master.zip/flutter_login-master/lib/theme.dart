// ignore_for_file: avoid_classes_with_only_static_members

import 'package:flutter/material.dart';

class LoginThemeHelper {
  /// used by the next screen after login to style the after-hero text
  static TextStyle? loginTextStyle;
}
